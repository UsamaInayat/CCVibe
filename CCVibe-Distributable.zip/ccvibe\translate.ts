/*
 * CCVibe - Auto-translate Roman Hindi/Urdu and Indonesian to English
 * Smart routing: picks best translator based on sentence analysis
 */

import { PluginNative } from "@utils/types";

import { settings } from "./settings";

export interface TranslationResult {
    original: string;
    translated: string;
    sourceLanguage: string;
}

// Native module for Groq API calls (runs in main process, bypasses CSP)
const Native = VencordNative.pluginHelpers.CCVibe as PluginNative<typeof import("./native")>;

// In-memory cache to avoid repeated API calls
const translationCache = new Map<string, TranslationResult>();
const wordCache = new Map<string, string>();
const inflightTranslations = new Map<string, Promise<TranslationResult>>();

// Maximum cache size to prevent memory issues
const MAX_CACHE_SIZE = 500;

// Profanity/slang keywords - use Dictionary + Google for these (unfiltered)
const PROFANITY_KEYWORDS = new Set([
    // Hindi/Urdu profanity
    "lun", "lund", "lora", "gandu", "gandhu", "gandy",
    "chutiya", "chutiye", "chutia", "chuut", "chut",
    "bhosdike", "bhosdi", "bsdk", "madarchod", "mc", "bc",
    "behenchod", "bhenchod", "bhen", "gaand", "gand",
    "harami", "haramkhor", "kutta", "kutte", "kutty",
    "kamina", "kamine", "kameena", "sala", "saale", "saala",
    "randi", "rand", "maa", "baap", "teri", "meri",
    // Indonesian profanity
    "anjing", "anjir", "anjay", "bangsat", "babi", "kampret",
    "keparat", "bajingan", "tai", "goblok", "bodoh", "tolol",
    "bego", "setan", "sialan", "kontol", "ngentot", "jancok", "dancok"
]);

// Common abbreviations - need word-by-word expansion
const ABBREVIATIONS = new Set([
    // Hindi/Urdu abbreviations
    "tm", "ap", "nhi", "ni", "hy", "hen", "kro", "kra",
    "rha", "rhi", "rhe", "ho", "kr", "sy", "k", "b", "v",
    "p", "h", "toh", "bhi", "kya", "kyu", "kyun", "aur",
    // Indonesian abbreviations (genuinely shortened forms only)
    "gw", "lo", "lu", "bgt", "yg", "dgn",
    "krn", "kl", "klo", "tp", "jd", "ntar", "msh", "gmn",
    "pgn", "gpp"
]);

// Slang dictionary for direct lookups
const SLANG_DICTIONARY: Record<string, string> = {
    // Profanity
    "lun": "dick",
    "lund": "dick",
    "lora": "dick",
    "gandu": "asshole",
    "gandhu": "asshole",
    "gandy": "asshole",
    "chutiya": "fucker/idiot",
    "chutiye": "fucker/idiot",
    "chutia": "fucker/idiot",
    "chut": "pussy",
    "chuut": "pussy",
    "bhosdike": "motherfucker",
    "bhosdi": "motherfucker",
    "bsdk": "motherfucker",
    "madarchod": "motherfucker",
    "mc": "motherfucker",
    "behenchod": "sisterfucker",
    "bhenchod": "sisterfucker",
    "bhen chod": "sisterfucker",
    "gaand": "ass",
    "gand": "ass",
    "harami": "bastard",
    "haramkhor": "bastard",
    "haram": "bastard",
    "kutta": "dog (insult)",
    "kutte": "dog (insult)",
    "kutty": "dog (insult)",
    "kamina": "bastard",
    "kamine": "bastard",
    "kameena": "bastard",
    "sala": "bastard",
    "saale": "bastard",
    "saala": "bastard",
    "ullu": "idiot (owl)",
    "gadha": "donkey/idiot",
    "bakwas": "nonsense/bullshit",
    "bakwaas": "nonsense/bullshit",
    "bewakoof": "fool",
    "pagal": "crazy",
    "paagal": "crazy",
    "chup": "shut up",
    "chupp": "shut up",
    "randi": "whore",
    "rand": "whore",

    // Hindi/Urdu abbreviations
    "tm": "you",
    "ap": "you (formal)",
    "nhi": "no",
    "ni": "no",
    "hy": "is",
    "hen": "are",
    "kro": "do",
    "kra": "did",
    "rha": "doing",
    "rhi": "doing",
    "rhe": "doing",
    "ho": "are",
    "kr": "do",
    "sy": "from",
    "k": "of",
    "b": "also",
    "v": "also",
    "p": "on",
    "h": "is",
    "toh": "then",
    "bhi": "also",
    "kya": "what",
    "kyu": "why",
    "kyun": "why",
    "aur": "and",

    // Indonesian profanity
    "anjing": "dog (insult)/damn",
    "anjir": "damn (euphemism)",
    "anjay": "damn/wow (euphemism)",
    "bangsat": "scoundrel/bastard",
    "babi": "pig (insult)",
    "kampret": "damn it",
    "keparat": "bastard",
    "bajingan": "scoundrel/villain",
    "tai": "shit",
    "goblok": "stupid/idiot",
    "bodoh": "stupid",
    "tolol": "idiot/dumb",
    "bego": "dumb/stupid",
    "setan": "devil/damn",
    "sialan": "damn it",
    "kontol": "dick",
    "ngentot": "fuck",
    "jancok": "fuck (Javanese)",
    "dancok": "fuck (Javanese)",

    // Indonesian internet slang
    "wkwk": "haha",
    "wkwkwk": "hahaha",
    "wkwkwkwk": "hahaha",
    "mantap": "awesome/cool",
    "mantul": "awesome",
    "gaskeun": "let's go/go for it",
    "kepo": "nosy/curious",
    "gabut": "bored with nothing to do",
    "baper": "easily emotional/oversensitive",
    "lebay": "overdramatic/exaggerating",
    "mager": "too lazy to move",
    "santuy": "chill/relax",
    "kuy": "let's go",
    "skuy": "let's go",
    "bucin": "lovesick person",
    "ngab": "bro/buddy",
    "gapapa": "it's okay",
    "gpp": "it's okay",

    // Indonesian abbreviations
    "gw": "I (me)",
    "gue": "I (me)",
    "gua": "I (me)",
    "lo": "you",
    "lu": "you",
    "bgt": "very",
    "yg": "that/which",
    "dgn": "with",
    "krn": "because",
    "kl": "if",
    "klo": "if",
    "tp": "but",
    "jd": "so/become",
    "ntar": "later",
    "msh": "still",
    "gmn": "how",
    "pgn": "want",
    "udah": "already",
    "emang": "indeed/really",
    "gimana": "how",
    "kayak": "like/similar to",
    "banget": "very/extremely",
    "dong": "you know/please (particle)",
    "sih": "actually/really (particle)",
    "deh": "okay then (particle)",
    "lho": "hey/really (particle)",
    "kan": "right?/isn't it (particle)",
    "nih": "here/this (particle)",
    "lah": "come on/okay (particle)",
};

// Track if native module is available
let nativeAvailable: boolean | null = null;

// =============================================================================
// SENTENCE ANALYSIS - Determines which translator to use
// =============================================================================

type TranslatorType = "dictionary" | "google" | "groq" | "word-by-word";

interface SentenceAnalysis {
    wordCount: number;
    hasProfanity: boolean;
    hasAbbreviations: boolean;
    abbreviationRatio: number;  // % of words that are abbreviations
    isQuestion: boolean;
    isConversational: boolean;
    recommendedTranslator: TranslatorType;
}

/**
 * Analyze sentence to determine best translation method
 */
function analyzeSentence(text: string, language: "hi-ur" | "id" = "hi-ur"): SentenceAnalysis {
    const lowerText = text.toLowerCase().trim();
    const words = lowerText.split(/\s+/).filter(w => w.length > 0);
    const wordCount = words.length;

    // Check for profanity
    const hasProfanity = words.some(word => PROFANITY_KEYWORDS.has(word));

    // Check for abbreviations
    const abbreviationCount = words.filter(word => ABBREVIATIONS.has(word)).length;
    const hasAbbreviations = abbreviationCount > 0;
    const abbreviationRatio = wordCount > 0 ? abbreviationCount / wordCount : 0;

    // Language-specific question and conversational signals
    const isQuestion = language === "id"
        ? /\?$/.test(text) || /^(apa|siapa|kapan|kenapa|mengapa|bagaimana|gimana|berapa)\b/i.test(lowerText)
        : /\?$/.test(text) || /^(kya|kyu|kyun|kaisa|kaisi|kaise|kahan|kab|kon|kaun)\b/i.test(lowerText);

    const conversationalPatterns = language === "id" ? [
        /\b(teman|kawan|sahabat|bro|sis|bang|om|tante|kakak|adik)\b/i,
        /\b(oke|sip|mantap|santuy|gaskeun|kuy)\b/i,
        /\b(gimana|gitu|gini|kayak|emang)\b/i,
        /\b(dong|sih|deh|nih|lho)\b/i,
    ] : [
        /\b(yaar|bhai|dost|bro|sis)\b/i,
        /\b(acha|theek|okay|ok|haan|han|ji)\b/i,
        /\b(kaise ho|kaisay ho|kya hal|sab theek)\b/i,
        /\b(chal|chalo|dekh|sun|bol)\b/i,
    ];
    const isConversational = conversationalPatterns.some(p => p.test(lowerText));

    // Determine best translator
    let recommendedTranslator: TranslatorType;

    // Single word in dictionary → Dictionary
    if (wordCount === 1 && SLANG_DICTIONARY[lowerText]) {
        recommendedTranslator = "dictionary";
    }
    // Contains profanity → Google (unfiltered) + Dictionary fallback
    else if (hasProfanity) {
        recommendedTranslator = "google";  // Google is unfiltered for profanity
    }
    // Heavy abbreviations (>40% of words) → Word-by-word
    else if (abbreviationRatio > 0.4) {
        recommendedTranslator = "word-by-word";
    }
    // Short phrase (1-3 words) → Google (literal is fine)
    else if (wordCount <= 3) {
        recommendedTranslator = "google";
    }
    // Long conversational/contextual sentence (4+ words) → Groq (context-aware)
    else if (wordCount >= 4 && (isConversational || isQuestion)) {
        recommendedTranslator = "groq";
    }
    // Default → Google
    else {
        recommendedTranslator = "google";
    }

    return {
        wordCount,
        hasProfanity,
        hasAbbreviations,
        abbreviationRatio,
        isQuestion,
        isConversational,
        recommendedTranslator
    };
}

// =============================================================================
// TRANSLATION FUNCTIONS
// =============================================================================

/**
 * Check if native module is available
 */
async function checkNativeAvailable(): Promise<boolean> {
    if (nativeAvailable !== null) return nativeAvailable;

    try {
        if (Native && typeof Native.translateWithGroq === "function") {
            nativeAvailable = true;
            console.log("[CCVibe] Native Groq module available!");
        } else {
            nativeAvailable = false;
            console.log("[CCVibe] Native module not available, Groq disabled");
        }
    } catch {
        nativeAvailable = false;
        console.log("[CCVibe] Native module check failed, Groq disabled");
    }

    return nativeAvailable;
}

/**
 * Translate using Groq AI via native module
 */
async function groqTranslate(text: string): Promise<string | null> {
    const apiKey = settings.store.groqApiKey;
    if (!apiKey) return null;

    try {
        const isAvailable = await checkNativeAvailable();
        if (!isAvailable) return null;

        const result = await Native.translateWithGroq(text, apiKey);

        if (result.success && result.translation) {
            if (isRealTranslation(text, result.translation)) {
                return result.translation;
            }
        } else if (result.error) {
            console.warn("[CCVibe] Groq error:", result.error);
        }

        return null;
    } catch (e) {
        console.error("[CCVibe] Groq translation failed:", e);
        return null;
    }
}

/**
 * Google Cloud Translation API v2 (literal).
 * Cloud Console keys must use translation.googleapis.com — not translate-pa / gtx (those return 403).
 */
async function googleTranslate(text: string, sourceLang: string): Promise<string | null> {
    const apiKey = settings.store.googleApiKey;
    if (!apiKey) return null;

    try {
        if (Native && typeof Native.translateWithGoogle === "function") {
            const result = await Native.translateWithGoogle(text, apiKey, sourceLang);
            if (result.success && result.translation) {
                return result.translation;
            }
            return null;
        }

        const url = `https://translation.googleapis.com/language/translate/v2?key=${encodeURIComponent(apiKey)}`;
        const body: Record<string, unknown> = {
            q: text,
            target: "en",
            format: "text",
        };
        if (sourceLang && sourceLang !== "auto") {
            body.source = sourceLang;
        }

        const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
        });
        if (!res.ok) return null;

        const data = await res.json() as {
            data?: { translations?: { translatedText?: string }[] };
        };
        return data?.data?.translations?.[0]?.translatedText ?? null;
    } catch {
        return null;
    }
}

/**
 * Check if translation is meaningfully different from original
 */
function isRealTranslation(original: string, translated: string): boolean {
    if (!translated) return false;
    const normOriginal = original.toLowerCase().replace(/[^a-z0-9]/g, "");
    const normTranslated = translated.toLowerCase().replace(/[^a-z0-9]/g, "");
    return normOriginal !== normTranslated;
}

/**
 * Try Google Translate with an ordered list of source language codes.
 * Returns the first successful, meaningfully different translation.
 */
async function tryTranslateWithLangs(text: string, langs: string[]): Promise<string | null> {
    for (const lang of langs) {
        const result = await googleTranslate(text, lang);
        if (result && isRealTranslation(text, result)) return result;
    }
    return null;
}

const tryGoogleTranslate = (text: string) => tryTranslateWithLangs(text, ["hi", "auto"]);
const tryIndonesianTranslate = (text: string) => tryTranslateWithLangs(text, ["id", "auto"]);

/**
 * Translate a single word using cache -> dictionary -> Google
 */
async function translateWord(word: string): Promise<string> {
    const lowerWord = word.toLowerCase();

    // Check word cache
    if (wordCache.has(lowerWord)) {
        return wordCache.get(lowerWord)!;
    }

    // Check dictionary first for slang
    if (SLANG_DICTIONARY[lowerWord]) {
        const result = SLANG_DICTIONARY[lowerWord];
        wordCache.set(lowerWord, result);
        return result;
    }

    // Try Google for this word
    const googleResult = await tryGoogleTranslate(lowerWord);
    if (googleResult) {
        wordCache.set(lowerWord, googleResult);
        return googleResult;
    }

    // No translation, return original
    return word;
}

/**
 * Translate word-by-word with dictionary
 */
async function translateWordByWord(text: string): Promise<string> {
    const words = text.split(/(\s+)/);
    const translatedParts: string[] = [];

    for (const part of words) {
        if (/^\s+$/.test(part) || part.length <= 1 || /^[^a-zA-Z]+$/.test(part)) {
            translatedParts.push(part);
            continue;
        }
        const translated = await translateWord(part);
        translatedParts.push(translated);
    }

    return translatedParts.join("");
}

// =============================================================================
// MAIN TRANSLATION FUNCTION - Smart Routing
// =============================================================================

/**
 * Main translation function with smart routing
 * @param text Text to translate
 * @param language Source language hint: "hi-ur" for Hindi/Urdu (default), "id" for Indonesian
 */
export async function translateToEnglish(text: string, language: "hi-ur" | "id" = "hi-ur"): Promise<TranslationResult> {
    const cached = translationCache.get(text);
    if (cached) return cached;

    const inflight = inflightTranslations.get(text);
    if (inflight) return inflight;

    const promise = translateToEnglishInternal(text, language);
    inflightTranslations.set(text, promise);

    try {
        return await promise;
    } finally {
        inflightTranslations.delete(text);
    }
}

async function translateToEnglishInternal(text: string, language: "hi-ur" | "id" = "hi-ur"): Promise<TranslationResult> {
    const cacheAndReturn = (translated: string, source: string): TranslationResult => {
        const result: TranslationResult = { original: text, translated, sourceLanguage: source };
        if (translationCache.size >= MAX_CACHE_SIZE) {
            const firstKey = translationCache.keys().next().value;
            if (firstKey) translationCache.delete(firstKey);
        }
        translationCache.set(text, result);
        return result;
    };

    try {
        const analysis = analyzeSentence(text, language);

        // Check if entire text is in dictionary
        const lowerText = text.toLowerCase().trim();
        if (SLANG_DICTIONARY[lowerText]) {
            return cacheAndReturn(SLANG_DICTIONARY[lowerText], "dictionary");
        }

        let result: string | null = null;

        // Pick the correct Google-level function based on source language
        const googleFn = language === "id" ? tryIndonesianTranslate : tryGoogleTranslate;

        // Route based on analysis
        switch (analysis.recommendedTranslator) {
            case "dictionary":
                result = await googleFn(text);
                if (result) {
                    return cacheAndReturn(result, "google");
                }
                break;

            case "google":
                result = await googleFn(text);
                if (result) {
                    return cacheAndReturn(result, "google");
                }
                if (analysis.hasProfanity) {
                    const wordByWord = await translateWordByWord(text);
                    if (isRealTranslation(text, wordByWord)) {
                        return cacheAndReturn(wordByWord, "word-by-word");
                    }
                }
                break;

            case "groq":
                // Google first for fast inline display; Groq only when Google fails
                result = await googleFn(text);
                if (result) {
                    return cacheAndReturn(result, "google");
                }
                result = await groqTranslate(text);
                if (result) {
                    return cacheAndReturn(result, "groq");
                }
                break;

            case "word-by-word":
                const wordByWord = await translateWordByWord(text);
                if (isRealTranslation(text, wordByWord)) {
                    return cacheAndReturn(wordByWord, "word-by-word");
                }
                result = await googleFn(text);
                if (result) {
                    return cacheAndReturn(result, "google");
                }
                break;
        }

        // Last resort: Google was already tried in every switch case above.
        // Try Groq and word-by-word as final fallbacks.
        result = await groqTranslate(text);
        if (result) {
            return cacheAndReturn(result, "groq");
        }

        const finalWordByWord = await translateWordByWord(text);
        if (isRealTranslation(text, finalWordByWord)) {
            return cacheAndReturn(finalWordByWord, "word-by-word");
        }

        console.log(`[CCVibe] No translation for: "${text}"`);
        return { original: text, translated: text, sourceLanguage: "unchanged" };

    } catch (error) {
        console.error("[CCVibe] Translation error:", error);
        return { original: text, translated: text, sourceLanguage: "error" };
    }
}

export function getCachedTranslation(text: string): string | null {
    return translationCache.get(text)?.translated ?? null;
}

// =============================================================================
// EXPORTS
// =============================================================================

export async function requestCspOverride(): Promise<boolean> {
    return await checkNativeAvailable();
}

export function clearCache(): void {
    translationCache.clear();
    wordCache.clear();
    inflightTranslations.clear();
}

export function getCacheStats() {
    return { size: translationCache.size, maxSize: MAX_CACHE_SIZE };
}
